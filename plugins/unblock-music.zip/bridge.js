/**
 * Unblock-Music 插件桥接器
 *
 * 由 proxy-server.js 在运行时动态加载。
 * 插件目录结构：
 *   plugins/unblock-music/
 *     bridge.js          ← 本文件
 *     manifest.json
 *     node_modules/
 *       @unblockneteasemusic/server/
 *         precompiled/app.js   ← 独立服务进程入口
 */
const path = require('path');

// 加载 @unblockneteasemusic/server 核心库
let match;
try {
  match = require('@unblockneteasemusic/server');
} catch (e) {
  console.error('[unblock-plugin] 加载 @unblockneteasemusic/server 失败:', e.message);
  match = null;
}

/**
 * 解析歌曲 URL（与 proxy-server.js 中原 match() 调用同签名）
 * @param {string} id - 网易云歌曲 ID
 * @returns {Promise<{url:string, source:string, br:number, size:number}|null>}
 */
async function resolveUrl(id) {
  if (!match) throw new Error('@unblockneteasemusic/server 未加载');
  const sources = ['kugou', 'bodian', 'pyncmd', 'kuwo'];
  process.env.SELECT_MAX_BR = 'true';
  return await Promise.race([
    match(id, sources),
    new Promise((_, reject) =>
      setTimeout(() => reject(new Error('all sources timeout after 10s')), 10000)
    ),
  ]);
}

/**
 * 获取 unblock 独立服务进程的启动路径
 * @returns {string|null} app.js 的绝对路径，不存在时返回 null
 */
function getServerEntry() {
  const p = path.join(__dirname, 'node_modules', '@unblockneteasemusic', 'server', 'precompiled', 'app.js');
  try {
    require.resolve(p);
    return p;
  } catch {
    return null;
  }
}

module.exports = { resolveUrl, getServerEntry, match };
